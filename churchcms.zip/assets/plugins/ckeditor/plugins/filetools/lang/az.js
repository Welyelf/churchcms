/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'filetools', 'az', {
	loadError: 'Faylını oxumaq mümkün deyil',
	networkError: 'Xəta baş verdi.',
	httpError404: 'Serverə göndərilməsinin zamanı xəta baş verdi (404 - fayl tapılmayıb)',
	httpError403: 'Serverə göndərilməsinin zamanı xəta baş verdi (403 - gadağandır)',
	httpError: 'Serverə göndərilməsinin zamanı xəta baş verdi (xətanın ststusu: %1)',
	noUrlError: 'Yükləmə linki təyin edilməyib',
	responseError: 'Serverin cavabı yanlışdır'
} );
